export { default } from "./Badge";
