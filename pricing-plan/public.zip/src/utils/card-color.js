const cardColors = [
  "#2196F3",
  "#FF9800",
  "#4CAF50",
  "#9C27B0",
  "#E91E63",
  "#00BCD4",
  "#795548",
];

export default cardColors;
