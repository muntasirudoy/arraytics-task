const cardColors = ["blue", "yellow", "green", "purple"];

export default cardColors;
