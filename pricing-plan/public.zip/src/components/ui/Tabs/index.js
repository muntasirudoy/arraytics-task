export { default } from "./Tabs";
