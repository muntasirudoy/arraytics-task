export { default } from "./badge";
