export { default } from "./pricing-module";
